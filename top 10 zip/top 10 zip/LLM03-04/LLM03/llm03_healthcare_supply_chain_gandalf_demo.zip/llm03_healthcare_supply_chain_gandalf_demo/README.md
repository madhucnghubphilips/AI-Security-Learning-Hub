# LLM03 Healthcare Supply Chain Gandalf Demo

Full Streamlit UI demo for OWASP LLM03 — Supply Chain Vulnerabilities with realistic healthcare examples.

Modes:
1. Vulnerable Healthcare AI
2. Secure Healthcare AI
3. Side-by-Side Comparison
4. Gandalf-style Interactive Levels
5. Logs, SBOM & Controls

Interactive levels hide default prompts and validate `levels.json` against `Answers.txt`.

Run:
```bash
cd llm03_healthcare_supply_chain_gandalf_demo
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
