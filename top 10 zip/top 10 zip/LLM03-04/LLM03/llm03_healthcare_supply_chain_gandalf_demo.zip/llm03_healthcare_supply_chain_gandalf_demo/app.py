import json
from pathlib import Path
from datetime import datetime
import pandas as pd
import streamlit as st
from scenarios import SCENARIOS
from validators import load_levels, validate_levels_vs_answers, check_answer

LOG=Path("security_events.jsonl")
def log(event, details):
    with LOG.open("a",encoding="utf-8") as f:
        f.write(json.dumps({"timestamp":datetime.utcnow().isoformat()+"Z","event_type":event,"details":details})+"\n")
def read_logs():
    if not LOG.exists(): return []
    out=[]
    for line in LOG.read_text(encoding="utf-8").splitlines():
        try: out.append(json.loads(line))
        except: pass
    return out
def clear_logs():
    if LOG.exists(): LOG.unlink()

st.set_page_config(page_title="LLM03 Healthcare Supply Chain Demo",page_icon="🧬",layout="wide")
errs=validate_levels_vs_answers()
if errs:
    st.error("Interactive Levels validation failed.")
    for e in errs: st.warning(e)
    st.stop()

st.title("🧬 LLM03 — Supply Chain Vulnerabilities")
st.caption("Healthcare end-to-end attack simulation with Gandalf-style interactive levels.")

with st.sidebar:
    mode=st.radio("Select Mode",["1. Vulnerable Healthcare AI","2. Secure Healthcare AI","3. Side-by-Side Comparison","4. Gandalf-style Interactive Levels","5. Logs, SBOM & Controls"])
    scenario_name=st.selectbox("Scenario",list(SCENARIOS.keys()))
    if st.button("Clear Logs"): clear_logs(); st.success("Logs cleared.")

s=SCENARIOS[scenario_name]
def cards():
    c1,c2,c3=st.columns(3)
    c1.info("**Category**\n\n"+s["category"])
    c2.warning("**Issue**\n\n"+s["issue"])
    c3.success("**Healthcare Context**\n\n"+s["context"])

if mode.startswith("1"):
    st.header("❌ Vulnerable Healthcare AI")
    cards()
    st.subheader("User Request"); st.code(s["request"])
    st.subheader("Real-Time Attack Story"); st.error(s["story"])
    st.subheader("Compromised Artifact"); st.code(s["artifact"])
    st.subheader("Proper Attack Output"); st.error(s["vulnerable"])
    st.warning("Learner task: identify the supply-chain issue.")
    log("vulnerable_attack",{"scenario":scenario_name,"issue":s["issue"]})

elif mode.startswith("2"):
    st.header("✅ Secure Healthcare AI")
    cards()
    c1,c2=st.columns(2)
    with c1:
        st.subheader("Controls Triggered")
        for x in s["controls"]: st.success(x)
    with c2:
        st.subheader("Secure Output")
        st.success(s["secure"])
    log("secure_demo",{"scenario":scenario_name,"controls":s["controls"]})

elif mode.startswith("3"):
    st.header("⚖️ Side-by-Side Comparison")
    cards()
    l,r=st.columns(2)
    with l:
        st.subheader("❌ Vulnerable Healthcare AI"); st.error(s["vulnerable"])
    with r:
        st.subheader("✅ Secure Healthcare AI"); st.success(s["secure"])

elif mode.startswith("4"):
    st.header("🧩 Gandalf-style Interactive Levels")
    st.caption("Default prompts are hidden. Identify the supply-chain weakness from real-time healthcare investigation clues.")
    levels=load_levels()
    if "solved" not in st.session_state: st.session_state.solved={}
    idx=st.selectbox("Choose Level",range(1,len(levels)+1),format_func=lambda i: levels[i-1]["title"])
    level=levels[idx-1]
    st.subheader(level["title"])
    st.markdown("**Difficulty:** "+level["difficulty"])
    st.info(level["question"])
    with st.expander("Hint"): st.write(level["hint"])
    ans=st.text_input("Your answer",placeholder="e.g., compromised dependency")
    if st.button("Submit Answer",type="primary"):
        ok,exp=check_answer(level["level_id"],ans)
        if ok:
            st.session_state.solved[level["level_id"]]=True
            st.success("Correct. Level solved.")
            st.write(level["learning"])
            log("level_solved",{"level_id":level["level_id"]})
        else:
            st.session_state.solved[level["level_id"]]=False
            st.error("Not correct yet. Try again.")
    solved=sum(1 for v in st.session_state.solved.values() if v)
    st.progress(solved/len(levels)); st.write(f"Solved: {solved}/{len(levels)}")
    st.success("Validation passed: levels.json and Answers.txt are synchronized.")
    st.download_button("Download Answers.txt",Path("Answers.txt").read_text(encoding="utf-8"),file_name="Answers.txt")

else:
    st.header("📊 Logs, SBOM & Controls")
    t1,t2,t3=st.tabs(["Security Logs","Runtime SBOM","Control Mapping"])
    with t1:
        data=read_logs()
        st.dataframe(pd.json_normalize(data),use_container_width=True) if data else st.info("No logs yet.")
    with t2:
        sbom=[
            ["ai-health-helper","2.4.1","2.4.2-unknown","Blocked"],
            ["healthcare-ai-core","1.8.0","1.8.0-hotfix-external","Drift"],
            ["med-ai-utils","internal-only","public higher version","Blocked"],
            ["fast-scheduler-plugin","not approved","active","Blocked"],
            ["hospital-rag-client","3.2.0","3.2.0","Approved"]]
        st.dataframe(pd.DataFrame(sbom,columns=["Component","Expected","Runtime","Status"]),use_container_width=True)
    with t3:
        rows=[
            ["Compromised dependency","SCA, allowlist, signed packages, pinning"],
            ["Poisoned RAG document","Provenance, ingestion scan, metadata trust score"],
            ["Tampered prompt template","Hash validation, approved template registry"],
            ["Malicious plugin","Plugin allowlist, least privilege, egress restriction"],
            ["Untrusted model","Trusted model registry, checksum validation"],
            ["SBOM mismatch","Build/runtime SBOM comparison"],
            ["Dependency confusion","Private registry and lockfile enforcement"],
            ["Egress anomaly","Network allowlist, telemetry, DLP alerts"]]
        st.dataframe(pd.DataFrame(rows,columns=["Risk","Recommended Controls"]),use_container_width=True)
