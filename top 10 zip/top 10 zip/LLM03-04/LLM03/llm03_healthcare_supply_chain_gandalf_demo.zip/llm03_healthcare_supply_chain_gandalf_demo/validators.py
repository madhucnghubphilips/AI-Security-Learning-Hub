from pathlib import Path
import json
def load_levels():
    return json.loads(Path("levels.json").read_text(encoding="utf-8"))
def load_answers():
    answers={}
    for line in Path("Answers.txt").read_text(encoding="utf-8").splitlines():
        if "|" in line:
            k,v=line.split("|",1); answers[k.strip()]=v.strip().lower()
    return answers
def validate_levels_vs_answers():
    levels=load_levels(); answers=load_answers(); errors=[]; ids=set()
    for l in levels:
        ids.add(l["level_id"]); exp=l["expected_answer"].lower()
        if l["level_id"] not in answers: errors.append("Missing answer: "+l["level_id"])
        elif answers[l["level_id"]] != exp: errors.append("Mismatch: "+l["level_id"])
    for extra in set(answers)-ids: errors.append("Extra answer: "+extra)
    return errors
def norm(x): return " ".join(x.strip().lower().split())
def check_answer(level_id, submitted):
    exp=load_answers().get(level_id,"")
    return norm(submitted)==norm(exp), exp
